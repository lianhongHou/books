#ifndef __TYPE_H__
#define __TYPE_H__

typedef int				 BOOL;
typedef long int           LONG;
typedef short int          SHORT;
typedef char               CHAR;

typedef unsigned long int  DWORD;
typedef unsigned short     WORD;
typedef unsigned char      BYTE;
typedef unsigned int       UINT;
typedef long long          INT64;
typedef unsigned long long UINT64;
  
typedef void*              LPVOID;
typedef int                HANDLE;       //ָ���ļ���������ָ��

#ifndef TRUE
      #define TRUE 1
#endif

#ifndef FALSE
      #define FALSE 0
#endif

#ifndef INVALID_HANDLE_VALUE
      #define INVALID_HANDLE_VALUE -1
#endif

#endif
