#ifndef __NET_SEND_H__
#define __NET_SEND_H__

#define MAX_CONNECTED 10
#define MAX_CONNECTED_NO 20
#define FIFO 1

#define MULTICAST_SEND_PORT 20001
#define UDP_SEND_PORT 20002

int init_tcp (char ip[16],int port);
THREAD_RETURN THREAD_API listen_tcp(void *sockfd);
THREAD_RETURN THREAD_API tcp_send_data (void * sockfd); 
void tcp_close (int sockfd); 

int init_udp (char ip[16],int port);
THREAD_RETURN THREAD_API udp_send_data (void * args);
void udp_close (int sockfd);
void udp_send(int sockfd,char remote_ip[16],int remote_port);

#endif

