    #include <string.h>
    #include <sys/ioctl.h>
    #include <sys/mman.h>
    #include <sys/time.h>
    #include <sys/types.h>
    #include <sys/stat.h>

    #include <sys/types.h>
    #include <sys/ipc.h>
    #include <sys/sem.h>

    #include <time.h>
    #include <pthread.h>
    #include <sched.h>
    #include <termios.h>
    #include <unistd.h>
    #include <signal.h>
    #include "types.h"
    #include "thread.h"

    void CreateThreadEvent(PT_CONDSYNC *event, BOOL bManualReset)
    {
        if (event) {
            pthread_mutex_init (&event->mutex, NULL);
            pthread_cond_init  (&event->cond,  NULL);
        }
    }
	
    void DestroyThreadEvent(PT_CONDSYNC *event)
    {
        if (event) {
            pthread_mutex_destroy   (&event->mutex);
            pthread_cond_destroy    (&event->cond);
        }
    }

   void init_active_handle(HANDLE active_handle) {
        active_handle = INVALID_HANDLE_VALUE;
    }

   void start_thread(ThreadStruct thread_param, LPVOID app_param_struct, thread_function_fp thread_loop) 
    {
        pthread_attr_init(&thread_param.hThreadAttr);
        pthread_attr_setscope(&thread_param.hThreadAttr, PTHREAD_SCOPE_SYSTEM);
        pthread_create(&thread_param.hThread, &thread_param.hThreadAttr, thread_loop, app_param_struct);
    }

    void set_thread_priority(ThreadStruct thread_param, int nPriority) 
    {
        pthread_getschedparam(thread_param.hThread, &thread_param.policy, &thread_param.hThreadPrior);
        thread_param.policy = SCHED_RR;	// SCHED_FIFO is another option
        thread_param.hThreadPrior.sched_priority = nPriority;
        pthread_setschedparam(thread_param.hThread, thread_param.policy, &thread_param.hThreadPrior);
    }