    #ifndef __THREAD_H__
    #define __THREAD_H__
    
    #include <pthread.h>
    #include <sched.h>
    #include "types.h"

    #define THREAD_RETURN void*
    #define THREAD_API

    typedef pthread_cond_t      PT_EVENT;
    typedef pthread_mutex_t     PT_MUTEX;
    typedef int                 VW_MUTEX;
    typedef pthread_cond_t      PT_COND;
    typedef pthread_t           PT_THREAD;
    typedef pthread_attr_t      PT_THREADATTR;
    typedef struct sched_param  PT_THREADPRIOR;
    typedef int                 PT_HANDLE;

    struct msg_query {
        PT_MUTEX     mutex;
        PT_COND      cond;
        unsigned int msg; // this is the actual message
    };

    typedef struct msg_query   PT_MSG;

    typedef enum {
        st_suspend = 1,
        st_resume = 2
    } PT_SIGSTATE;

    typedef struct{
        PT_EVENT    event;
        PT_COND     cond;
        PT_MUTEX    mutex;
        PT_SIGSTATE ss;
        int         signal;
    } PT_CONDSYNC;

   typedef struct {
       PT_HANDLE       hActive;
       PT_THREAD       hThread;
       PT_THREADATTR   hThreadAttr;
       PT_THREADPRIOR  hThreadPrior;
       int             policy;
    } ThreadStruct;

typedef void *(*thread_function_fp)(void *parm);

 #define THREAD_PRIORITY_TIME_CRITICAL   10
 #define THREAD_PRIORITY_HIGHEST         9
 #define THREAD_PRIORITY_ABOVE_NORMAL    8
 #define THREAD_PRIORITY_NORMAL          7
 #define THREAD_PRIORITY_BELOW_NORMAL    5
 #define THREAD_PRIORITY_LOWEST          1
 #define THREAD_PRIORITY_IDLE            0

  #define VW_MAX_THREAD_PRIORITY  THREAD_PRIORITY_TIME_CRITICAL

  unsigned get_thread_message(void *Msg, const char *Port, void *parm1, void *parm2);
  unsigned get_message_ID(const void *Msg);
  unsigned send_thread_message(unsigned long ThreadID, void *Msg, void *parm1, void *parm2);

  void CreateThreadEvent(PT_CONDSYNC *event, BOOL bManualReset);

 void DestroyThreadEvent(PT_CONDSYNC *event);

 void init_active_handle(HANDLE active_handle);
	
 void start_thread(ThreadStruct thread_param, LPVOID app_param_struct,  thread_function_fp thread_loop) ;

 void set_thread_priority(ThreadStruct thread_param, int nPriority);

#endif

