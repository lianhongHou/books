#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include "thread.h"

#include "define.h"
#include "types.h"
#include "ctrl.h"
#include "net_send.h"

#define TIME_OUT	2000




struct reply_msg {
	ctl_hdr head;
	char	data;
};
//global variable
int g_is_running=0; //data socket state
int g_is_dev_busy=0; //device state


/*int quit_socket=0;*/
int is_connected[25+MAX_CONNECTED_NO+MAX_CONNECTED_NO];

#define	IS_CONNECTED_CTRL(a)	is_connected[25+MAX_CONNECTED_NO+a] 

void
tcp_close (int sockfd) {
    close(sockfd);
}

int
init_tcp (char ip[16],int port) {
    int fd;
    struct sockaddr_in addr;
    int optval = 1;
    if ((fd = socket(AF_INET,SOCK_STREAM,0))<0) {
        perror("socket");
        return -1;
    }
    printf("listen sock:%d\n",fd);
    bzero(&addr,sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = INADDR_ANY;

    setsockopt(fd,SOL_SOCKET,SO_REUSEADDR,&optval,sizeof(optval));

    if (bind(fd,(struct sockaddr *)&addr,sizeof(addr)) < 0) {
        sleep(5);
        if (bind(fd,(struct sockaddr *)&addr,sizeof(addr)) < 0) {
            perror("bind");
            return -1;
        }
    }
    if (listen (fd,MAX_CONNECTED) < 0) {
        perror("listen");
        return -1;
    }
    return fd;
};


THREAD_RETURN THREAD_API
ctrl_msg_proc(void * args){
	int fd=*((int*)args);
	ctl_hdr *rcv_hdr;
	char buffer[256];
	int rcv_len=0;
	unsigned char ret_code=0;
	int is_me=0;

	//set recv timeout
	struct timeval tm_out;
	tm_out.tv_sec=TIME_OUT;
	tm_out.tv_usec=0;

	if ((setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&tm_out,sizeof(tm_out)))<0)	{

		perror("setsockopt");
		exit(-1);
	}

	do {
		sleep(300);
		bzero(buffer,sizeof(buffer)); 
		rcv_len=recv(fd,buffer,sizeof(buffer),0);
		printf("rcv_len is %d\n",rcv_len);
		if (rcv_len<0) {
	
			printf("socket %d timeout \n",fd);
			break;
		}

		if (rcv_len>0) {
	
		rcv_hdr=(ctl_hdr*)buffer;
		ret_code=proc_cmd(buffer,fd,&is_me);
		printf(" proc_cmd return value is %d\n",ret_code);
		

		struct reply_msg rpl_msg;
		rpl_msg.head.ki=KI_REPLY;
		rpl_msg.head.len=10;
		rpl_msg.head.mo=MO_SERVER;
		rpl_msg.head.ttl=0;
		rpl_msg.head.type=TYPE_REPLY;
		rpl_msg.data=ret_code;
		send(fd,&rpl_msg,rpl_msg.head.len,0);
	}
		
	} while((ret_code!=KI_QUIT));
	
	//unlock the resource if necessary
	if (is_me&&g_is_dev_busy) {
		g_is_dev_busy=0;
	}
	
	close(fd);
	IS_CONNECTED_CTRL(fd)=0;
	return 0;
	
}


THREAD_RETURN THREAD_API
ctrl_s(void *args){
	int newsockfd,fd, sockfd;
	fd_set readfds,exceptfds;
	struct sockaddr_in addr;
	socklen_t addr_len = sizeof(struct sockaddr_in);
	char buffer[256];
	char buffer_out[256];
	char res[7];
	struct timeval timeout;
	timeout.tv_sec = 3;
	timeout.tv_usec =0;

	sockfd = *((int*)args);
	
	for (fd=0;fd<MAX_CONNECTED;fd++) {
		IS_CONNECTED_CTRL(fd)=0;
	}

	IS_CONNECTED_CTRL(sockfd)=1;
	
	
	ThreadStruct ctrl_socket_thd_struct;

	while (1) {
		sleep(3);
		FD_ZERO(&readfds);
		FD_ZERO(&exceptfds);

		for (fd=3;fd<MAX_CONNECTED;fd++)
		{
			if (IS_CONNECTED_CTRL(fd)) {
				FD_SET(fd,&readfds);
				FD_SET(fd,&exceptfds);
			}
		}
		
		if (select(MAX_CONNECTED,&readfds,NULL,&exceptfds,&timeout)<0) {
			perror("select");
			continue;
		}


		for (fd=3;fd<MAX_CONNECTED_NO;fd++) {
			if (FD_ISSET(fd,&exceptfds)) {
				if (sockfd!=fd) {
					printf("exceptfds connection closed \n");
					close(fd);
					IS_CONNECTED_CTRL(fd)=0;
				}
			}
			if (FD_ISSET(fd,&readfds)) {
				if (sockfd==fd) {
					if ((newsockfd=accept(sockfd,(struct sockaddr *)&addr,&addr_len))<0) {
						perror("accept");
					}
					else{
						printf("connect from %s sock: %d\n",inet_ntoa(addr.sin_addr),newsockfd);
						if (newsockfd<MAX_CONNECTED_NO) {
							IS_CONNECTED_CTRL(newsockfd)=1;
						}
						else
							close(newsockfd);
					}
				}
				else{
					bzero(buffer,sizeof(buffer));
					int recv_len=0;
					
					if (IS_CONNECTED_CTRL(fd)==2) {
						printf("readfds connection closed .\n");
						close(fd);
						IS_CONNECTED_CTRL(fd)=0;
					}
					else{
						recv_len =  recv(fd,buffer,sizeof(buffer),0);
						if (recv_len>0){
							bzero(buffer_out,sizeof(buffer_out));
							if (check_user(buffer)!=RPL_AUTH_PASSED) {
								sprintf(res,"%c%c%c%c%c%c%c",0x06,0x62,0x63,0x64,
									KI_REPLY,RPL_AUTH_PASSED,0);
								send(fd,res,7,0);
								printf("check user successful\n");
								IS_CONNECTED_CTRL(fd)=2;
								init_active_handle(ctrl_socket_thd_struct.hActive);
								start_thread(ctrl_socket_thd_struct,&fd,&ctrl_msg_proc);
								set_thread_priority(ctrl_socket_thd_struct,VW_MAX_THREAD_PRIORITY-1);
								break;
							}
							else{
								sprintf(res,"%c%c%c%c%c%c%c",0x06,0x68,0x69,0x67,
									KI_REPLY,RPL_AUTH_FAILED,0);
								send(fd,res,7,0);
								tcp_close(fd);
								IS_CONNECTED_CTRL(fd)=0;
							}
						} 
					}
				}
			}
		}
	}
	
	for (fd=0;fd<MAX_CONNECTED_NO;fd++) {
		IS_CONNECTED_CTRL(fd)=0;
	}
	tcp_close(sockfd);
	sleep(5);

	printf("listen thread finish! \n");
	return 0;
}

int main(){
	int fd;
	fd=init_tcp("210.25.137.234",8101);
	ThreadStruct ctrl_socket_thread;
	init_active_handle(ctrl_socket_thread.hActive);
	start_thread(ctrl_socket_thread,&fd,&ctrl_s);
	while (1) {
		sleep(1000);
	}
	return 0;
}

