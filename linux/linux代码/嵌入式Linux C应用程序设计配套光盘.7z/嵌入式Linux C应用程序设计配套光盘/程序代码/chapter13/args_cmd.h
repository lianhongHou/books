#ifndef _ARGS_CMD_H_
#define _ARGS_CMD_H_

#define GET_ARG_OUTPUT "/etc/get_sdk_arg.out"

#define ARGS_MSG_KEY 12345
#define ARGS_MSG_SIZE 512
#define SET_ARG 1
#define GET_ARG 2
#define SET_BIT_RATE 3
#define SET_RESOLUTION 4
#define SET_BCSH 5
#define SET_FRAME_RATE 6
#define SET_MOTION_DETECTOR 7
#define SET_GOP_STRUCTURE 8

#define GET_VIDEO_FORMAT 201
#define GET_BIT_RATE 202
#define GET_RESOLUTION 203
#define GET_BCSH 204

#define STOP_MOTION_DETECTOR 401

#define UDP_CMD         601
#define TCP_CMD         602
#define MULTICAST_CMD   603
#define FILE_CMD        604
#define GET_PIC         605

struct ArgsMsgContent_t {
    int nType;
    char nContent[ARGS_MSG_SIZE];
};  

#endif

