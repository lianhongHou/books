#ifndef _BLX_PROC_CMD
#define _BLX_PROC_CMD

#define MAX_CONNECTED 10
#define MAX_CONNECTED_NO 20

unsigned char proc_cmd(const void * buf, const int fd,int * is_me);
unsigned char check_user(char * buf);
#endif

