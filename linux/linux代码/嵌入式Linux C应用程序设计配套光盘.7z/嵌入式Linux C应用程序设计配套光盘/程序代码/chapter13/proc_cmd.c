#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <termios.h>
#include <errno.h>

#include "args_cmd.h"
#include "thread.h"


#include "types.h"
#include "define.h"
#include "ctrl.h"

#define CHECK_DEV	if (!(*is_me)) {\
						printf("I have not set anything\n");\
						if (g_is_dev_busy) {\
							printf("device is busy now \n");\
							return RPL_DEV_BUSY;\
						}else{	\
							*is_me =1;\
							g_is_dev_busy =1;\
						}\
					}
int sound_state=0;
extern int g_is_running;
extern int g_is_dev_busy;

extern struct  sockaddr_in tcp_client_addr[25];

int do_sth(){
	return RPL_NOT_IMPLEMENT;
}

//extern THREAD_RETURN THREAD_API play_snd(void* arg);
int get_com_setting( char * buf, unsigned int *nlen )
{
 if ( *nlen == 0)
 {
 }

 strcpy(buf,"9600,8,N,1");
 return 0;
}

static inline int eight_bit_add(char *ch, int startx, int endx)
{
 int count = 0;
 int i;
 for ( i = startx ; i <= endx; ++ i )
  {	count += ch[i];
  }
 return count % 256;
}

int control_device( int camera_no, uint16_t action, int com_handle,const char * add_data, size_t length )
{
 char ch[7] = {0xff,camera_no + 1,0,0,0,0,0};
 switch(action)
 {
  case 0://stop
    ch[2] = 0;
    ch[3] = 0;
    ch[4] = 0;
    ch[5] = 0;
    break;
  case 1://up
    ch[2] = 0;
    ch[3] = 0x08;
    ch[4] = 0;
    ch[5] = 0x2f;
    printf("action:up\n");
   break;
  case 2://down
    printf("case 2!\n");
    ch[2] = 0;
    ch[3] = 0x10;
    ch[4] = 0;
    ch[5] = 0x2f;
    printf("action:down\n");
   break;
  case 3://left
    ch[2] = 0;
    ch[3] = 0x04;
    ch[4] = 0x2f;
    ch[5] = 0;
    printf("action:left\n");
   break;
  case 4://right
    ch[2] = 0;
    ch[3] = 0x02;
    ch[4] = 0x2f;
    ch[5] = 0;
    printf("action:right\n");
   break;
  case 5://aperture+
    ch[2] = 0x02;
    ch[3] = 0;
    ch[4] = 0;
    ch[5] = 0;
    printf("action:iris +\n");
   break;
  case 6://aperture-
    ch[2] = 0x04;
    ch[3] = 0;
    ch[4] = 0;
    ch[5] = 0;
    printf("action:iris -\n");
   break;
  case 7://zoom +
    ch[2] = 0;
    ch[3] = 0x20;
    ch[4] = 0;
    ch[5] = 0;
    printf("action:zoom+\n");
   break;
  case 8://zoom-
    ch[2] = 0;
    ch[3] = 0x40;
    ch[4] = 0;
    ch[5] = 0;
    printf("action:zoom-\n");
   break;
  case 9://focus+
    ch[2] = 0x01;
    ch[3] = 0;
    ch[4] = 0;
    ch[5] = 0;
    printf("action:focus+\n");
   break;
  case 10://focus-
    ch[2] = 0;
    ch[3] = 0x80;
    ch[4] = 0;
    ch[5] = 0;
    printf("aciont:focus-\n");
   break;
  case 11:
    ch[2] = 0x00;
    ch[3] = 0x07;
    ch[4] = 0x00;
    ch[5] = 0x63;
   break;
  case 12:
    ch[2] = 0x00;
    ch[3] = 0x07;
    ch[4] = 0x00;
    ch[5] = 0x60;
   break;
  case 13:
    ch[2] = 0;
    ch[3] = 0x09;
    ch[4] = 0;
    ch[5] = 0x01;
   break;
  case 14:
    ch[2] = 0;
    ch[3] = 0x0b;
    ch[4] = 0;
    ch[5] = 0x01;
   break;
  case 15:
    ch[2] = 0;
    ch[3] = 0x09;
    ch[4] = 0;
    ch[5] = 0x04;
   break;
  case 16:
    ch[2] = 0;
    ch[3] = 0x0b;
    ch[4] = 0;
    ch[5] = 0x04;
   break;
  case 17:
    ch[2] = 0;
    ch[3] = 0x09;
    ch[4] = 0;
    ch[5] = 0x02;
   break;
  case 18:
    ch[2] = 0;
    ch[3] = 0x0b;
    ch[4] = 0;
    ch[5] = 0x02;
   break;
  case 19:
    ch[2] = 0;
    ch[3] = 0x09;
    ch[4] = 0;
    ch[5] = 0x03;
   break;
  case 20:
    ch[2] = 0;
    ch[3] = 0x0b;
    ch[4] = 0;
    ch[5] = 0x03;
   break;
  
  case 8200:
  {
	printf("8200!\n");
    if ( length == 2 || length == 4 )
    {
      int i = 0;
AGAIN:      
    	printf("%c,%d,",add_data[i],add_data[i+1]);
	    switch (add_data[i])
    	{
		    case 'U':
	  printf("case U!\n");
          ch[3] += 0x08;
          ch[5] = add_data[i+1] * 0x3F / 255;
          break;
    		case 'D':
          ch[3] += 0x10;
          ch[5] = add_data[i+1] * 0x3F / 255;
          break;
		case 'L':
          ch[3] += 0x04;
          ch[4] = add_data[i+1] * 0x3F / 255;
          break;
    		case 'R':
          ch[3] += 0x02;
          ch[4] = add_data[i+1] * 0x3F / 255;
          break;
    		default:
  		  	return -1;
    	}
     
    	if ( length == 4 )
      {
        i += 2;
        length = 120; // is not 4
        goto AGAIN;
      }  
      printf("\n");
    }
    else 
	    return -1;
       
    break;
  }
  case 8202:
  {
    ch[2] = 0;
    ch[3] = 0;
    ch[4] = 0;
    ch[5] = 0;
    break;
  }
  case 8206:
  {
    if ( add_data[0] <= 32 )
    {
      ch[2] = 0x00;
      ch[3] = 0x03;
      ch[4] = 0x00;
      ch[5] = add_data[0];
    }
    else
    {
      ch[2] = 0x02;
      ch[3] = 0xFF;
      ch[4] = add_data[0] - 33;
      ch[5] = 0x01;
    }
    break;
  }
  case 8208:
 {
 	return -1;
 }
  break;
  case 8210:
  {
    if ( add_data[0] <= 32 )
    {
      ch[2] = 0x00;
      ch[3] = 0x07;
      ch[4] = 0x00;
      ch[5] = add_data[0];
    }
    else
    {
      ch[2] = 0x02;
      ch[3] = 0xFF;
      ch[4] = add_data[0] - 33;
      ch[5] = 0x00;
    }
    break;
  }
  case 8212:
   return -1;
  case 8300:
  {
    if ( add_data[0] )
      ch[2] = 0x02;
    else
      ch[2] = 0x04;

    ch[3] = 0;
    ch[4] = 0;
    ch[5] = 0;
    break;
  }
  case 8302:
  {
    ch[2] = 0;
    ch[4] = 0;
    ch[5] = 0;
    if ( add_data[0] )
      ch[3] = 0x20;
    else
      ch[3] = 0x40;
    break;
  }
  case 8304:
  {
    if ( add_data[0] )
      ch[2] = 0x01;
    else
      ch[3] = 0x80;
    break;
  }
  case 8306:
  case 8308:
  case 8310:
  {
    ch[2] = 0;
    ch[3] = 0;
    ch[4] = 0;
    ch[5] = 0;
	printf("8310!\n");
    break;
  }
  case 8204:
  {
    if ( add_data[0] )
    {
      ch[2] = 0x10;
      ch[3] = 0x00;
      ch[4] = 0x00;
      ch[5] = 0x00;
      ch[6] = eight_bit_add(ch,1,5);
      write(com_handle, ch, 7);
           
    }
    ch[2] = 0x00;
    ch[3] = 0x07;
    ch[4] = 0x00;
    if ( add_data[0] )
      ch[5] = 0x63;
    else
      ch[5] = 0x60;
    break;
  }
  
  default: // not supported!
   return -1;
 }

 ch[6] = eight_bit_add(ch,1,5);
 write(com_handle, ch, 7);
 usleep(500000); 

 return 0;
}

int set_opt(int fd,int nSpeed, int nBits, char nEvent, int nStop)
{
	
	struct termios newtio,oldtio;
	if  ( tcgetattr( fd,&oldtio)  !=  0) { 
		perror("SetupSerial 1");     
		return -1;  
	}
	

	bzero( &newtio, sizeof( newtio ) );
	
	newtio.c_cflag &= ~CSIZE; 
	// set the nBits 
  	switch( nBits )
  	{
  	case 7:
  	    	newtio.c_cflag |= CS7;
		break;
  	case 8:
      		newtio.c_cflag |= CS8;
	  	break;
  	}
  
//Set the Check mode and StopBit
	switch( nEvent )
	{
	case 'O': //odd
		newtio.c_cflag |= PARENB;
		newtio.c_cflag |= PARODD;
		newtio.c_iflag |= (INPCK | ISTRIP);

		break;
	case 'E': //even
		newtio.c_iflag |= (INPCK | ISTRIP);
		newtio.c_cflag |= PARENB;
		newtio.c_cflag &= ~PARODD;

		break;
  	case 'N':  //NULL
  		newtio.c_cflag &= ~PARENB;
  		break;
  	}
  	newtio.c_cflag  |=  CLOCAL | CREAD;

  	switch( nSpeed )
  	{
    	case 2400:
    		cfsetispeed(&newtio, B2400);
	    	cfsetospeed(&newtio, B2400);
      		break;
    	case 4800:
      		cfsetispeed(&newtio, B4800);
      		cfsetospeed(&newtio, B4800);
      		break;
    	case 9600:
    		cfsetispeed(&newtio, B9600);
	    	cfsetospeed(&newtio, B9600);
      		break;
    	case 115200:
    		cfsetispeed(&newtio, B115200);
	       	cfsetospeed(&newtio, B115200);
      		break;
    	case 460800:
    		cfsetispeed(&newtio, B460800);
	    	cfsetospeed(&newtio, B460800);
	    	break;
    	default:
    		cfsetispeed(&newtio, B9600);
	    	cfsetospeed(&newtio, B9600);
      		break;
  	}
  
  	if( nStop == 1 )
		newtio.c_cflag &=  ~CSTOPB;
  	else if ( nStop == 2 )
		newtio.c_cflag |=  CSTOPB;
  	
  	newtio.c_cc[VTIME]  = 0;//150;//2; //is 200 ms
  	newtio.c_cc[VMIN] = 0;//1;
  	tcflush(fd,TCIFLUSH);
  	if((tcsetattr(fd,TCSANOW,&newtio))!=0)
  	{
 	 	perror("com set error");
  	 	return -1;
  	}
  	return 0;
}

int open_port(int*fd,const char * com_Properity, int comport)
{
	long  vdisable;
 	if (comport==1)
	{	*fd = open( "/dev/ttyS0", O_RDWR);
		if (-1 == *fd){
			perror("Can't Open Serial Port");
			return(-1);
		}
		
	}
	else if(comport==2)
	{	*fd = open( "/dev/ttyS1", O_RDWR);
		if (-1 == *fd){
			perror("Can't Open Serial Port");
			return(-1);
		}
		
	}
	else if (comport==3)
	{
		*fd = open( "/dev/ttyS2", O_RDWR|O_NOCTTY|O_NDELAY);
		if (-1 == *fd){
			perror("Can't Open Serial Port");
			return(-1);
		}
		else{
			if(fcntl(*fd, F_SETFL, 0)<0)
				printf("fcntl failed!\n");
		}
		if(isatty(STDIN_FILENO)==0)
			printf("standard input is not a terminal device\n");
		if((vdisable = fpathconf(STDIN_FILENO,_PC_VDISABLE))<0)
			printf("fpathconf error!\n");
	}
	 if( com_Properity )
    {
      char buf[40];
      int nSpeed,nBits,nStop;
      char nEvent;
      int i=0;
      char *p_data = (char *)com_Properity;
      while( *p_data  )
      {
          if( *p_data == ',' )
          {
              buf[i] = '\0';
              p_data++;
              break;
          }
          buf[i++] = *p_data++;
      }
      nSpeed = atoi( buf );
      i = 0;
      while( *p_data  )
      {
          if( *p_data == ',' )
          {
              buf[i] = '\0';
              p_data++;
              break;
          }
          buf[i++] = *p_data++;
      }
      nBits = atoi( buf );
      i = 0;
      while( *p_data  )
      {
          if( *p_data == ',' )
          {
              buf[i] = '\0';
              p_data++;
              break;
          }
          buf[i++] = *p_data++;
      }
      nEvent = buf[0];
      i = 0;
      while( *p_data )
          buf[i++] = *p_data++;
      buf[i] = '\0';
      nStop = atoi( buf );
      return set_opt( *fd,nSpeed, nBits, nEvent, nStop );
    }
    else
      return set_opt( *fd,2400, 8, 'E', 1 );

}
void control_yuntai(uint16_t action) 
{
	int fd;
	char *set="2400,8,N,1";
	if(open_port(&fd,set,3)<0){
		perror("set options error");
		return;
	}
	 control_device(0,action,fd,"u2",0);
	 close(fd);
 	 if(open_port(&fd,set,3)<0){
		perror("set options error");
		return;
	}
	 control_device(0,0,fd,"",0);
	 close(fd);
	 return;
 }



//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////


unsigned char 
check_user(char * buf){
	
	if (buf==NULL) {
		return  RPL_UNKOWN_ERR;
	}
	
	char user_conf[MAX_CONNECTED][128],passwd_conf[MAX_CONNECTED][128];
	int user_conf_num = 0;
	FILE *file_user = NULL;
    file_user = fopen("/etc/tcp_user.conf","r");
    if (file_user == NULL) {
        printf("tcp user configuration file doesn't exist!!");
        return 0;
    }
	
	//load user passwd
    while (!feof(file_user) && user_conf_num < MAX_CONNECTED) {
        if (!feof(file_user))
            fscanf(file_user,"%s",user_conf[user_conf_num]);
        else
            break;
        if (!feof(file_user))
            fscanf(file_user,"%s",passwd_conf[user_conf_num]);
        else
            break;
        user_conf_num++;
    }
	fclose(file_user);
	
	
	//compare user and its password
	char user_name[128],user_passwd[128];
	char *delim=":\012";
	char *p = NULL;
	p=strtok(buf,delim);
	if (p==NULL) {
		return RPL_AUTH_FAILED;
	}
	strcpy(user_name,p);
	p = strtok(NULL,delim);
	if (p==NULL) {
		return RPL_AUTH_FAILED;
	}
	strcpy(user_passwd,p);
	int i;
	for (i=0;i<user_conf_num;i++) {
		if (!strcmp(user_name,user_conf[i]) && !strcmp(user_passwd,passwd_conf[i])) {
			printf("user : %s auth passed\n",user_name);
			return RPL_AUTH_PASSED ;
		}
	}
	
	return RPL_AUTH_FAILED;
}

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

unsigned char 
proc_cmd(const void * buf,const int fd,int * is_me){
	int msqid;
	struct ArgsMsgContent_t msgp;
	msqid = msgget(ARGS_MSG_KEY,IPC_CREAT|0600);
	
	ctl_hdr *hdr;
	int data_len=0;
	char *data;
	unsigned char  ret;
	hdr=(ctl_hdr*)buf;
	data=(char*)buf+5;


	data_len=(int)hdr->len;



	switch(hdr->ki) {

	case KI_START:{
		printf("get command: KI start\n");
		if (g_is_running) {
			return RPL_RUNNING;
		}else
		{
			unsigned short port;
			memcpy(&port,data,2);
			msgp.nType = TCP_CMD;
			sprintf(msgp.nContent,"%d%s%d",2,"127.0.0.1",port);
			msgsnd(msqid,&msgp,ARGS_MSG_SIZE,IPC_NOWAIT);
			g_is_running =1;
			ret=RPL_OK;
		}
	}
	break;
	case KI_RATE_SET:{
		printf("get command: KI rate set\n");
		CHECK_DEV;
		uint16_t rate;
		memcpy(&rate,data,sizeof(uint16_t));
		msgp.nType=SET_BIT_RATE;
		sprintf(msgp.nContent,"%d",rate);
		if (msgsnd(msqid,&msgp,ARGS_MSG_SIZE,IPC_NOWAIT)!=0) {
			ret = RPL_UNKOWN_ERR;
		}
		else
			ret=RPL_OK;
		
	}
	break;
	case KI_FRAME_SET:{

		printf("get command: KI frame set\n");
		CHECK_DEV;
		uint16_t	frame_rate,frame_skip;
		memcpy(&frame_rate,data,2);
		memcpy(&frame_skip,data+2,2);
		msgp.nType = SET_FRAME_RATE;
		sprintf(msgp.nContent,"%d %d",(int)frame_rate,(int)frame_skip);
		if (msgsnd(msqid,&msgp,ARGS_MSG_SIZE,IPC_NOWAIT)!=0) {
			ret = RPL_UNKOWN_ERR;
		}
		else
			ret=RPL_OK;

	}
	break;
	case KI_RESOLUTION_SET:{

		printf("get command: KI resolution set\n");
		CHECK_DEV;

		uint16_t width,high;
		memcpy(&width,data,2);
		memcpy(&high,data+2,2);

		msgp.nType = SET_RESOLUTION;
		sprintf(msgp.nContent,"%d %d",(int)width,(int)high);
		
		if (msgsnd(msqid,&msgp,ARGS_MSG_SIZE,IPC_NOWAIT)!=0) {
			ret = RPL_UNKOWN_ERR;
		}
		else
			ret=RPL_OK;
	}
	break;
	case KI_BCSH_SET:{

		printf("get command: KI bash set\n");
		CHECK_DEV;
		
		uint8_t bright,contrast,saturation,sharp,hue;
		sscanf(data,"%c%c%c%c%c",&bright,&contrast,&saturation,&sharp,&hue);
		msgp.nType = SET_BCSH;
		sprintf(msgp.nContent,"%d %d %d %d %d",(int)bright,(int)contrast,(int)saturation,
			(int)sharp,(int)hue);

		if (msgsnd(msqid,&msgp,ARGS_MSG_SIZE,IPC_NOWAIT)!=0) {
			ret = RPL_UNKOWN_ERR;
		}
		else
			ret=RPL_OK;
	}
	break;

		
	case KI_MOTION_DETECTOR_SET:{
	
		printf("get command: KI motion detector set\n");
		CHECK_DEV;
		
		int region,left,right,top,bottom,thresh;
		sscanf(data,"%d%d%d%d%d %d",&region,&left,&right,&top,&bottom,&thresh);
		msgp.nType =SET_MOTION_DETECTOR;
		sprintf(msgp.nContent,"%d %d %d %d %d %d",region,left,right, top,bottom,thresh);
		if (msgsnd(msqid,&msgp,ARGS_MSG_SIZE,IPC_NOWAIT)!=0) {
			ret = RPL_UNKOWN_ERR;
		}
		else
			ret=RPL_OK;

	}
	break;
	case KI_MOTION_DETECTOR_STOP:{

		printf("get command: KI motion detector stop\n");
		CHECK_DEV;
		
		int region;
		memcpy(&region,data,4);
		msgp.nType = STOP_MOTION_DETECTOR;
		sprintf(msgp.nContent,"%d",region);

		if (msgsnd(msqid,&msgp,ARGS_MSG_SIZE,IPC_NOWAIT)!=0) {
			ret = RPL_UNKOWN_ERR;
		}
		else
			ret=RPL_OK;
	}
	break;
	case KI_GOP_STRUCTURE_SET:{

		printf("get command: KI structure set\n");
		CHECK_DEV;

		int N,M;
		sscanf(data,"%d%d",&N,&M);
		msgp.nType = SET_GOP_STRUCTURE;
		sprintf(msgp.nContent,"%d %d",N,M);

		if (msgsnd(msqid,&msgp,ARGS_MSG_SIZE,IPC_NOWAIT)!=0) {
			ret = RPL_UNKOWN_ERR;
		}
		else
			ret=RPL_OK;
	}
	break;

	case KI_SAVE_POLICY_SET:{
		
		printf("get command: KI save policy set\n");
		CHECK_DEV;
		
		ret=do_sth();
	}
	break;		
						
	case KI_YUNTAI:{

		printf("get command: control yuntai\n");
		CHECK_DEV;
		
		uint16_t direction;
		memcpy(&direction,data,2);
		control_yuntai(direction); 
		ret=do_sth();
	}
	printf("done\n");
	break;
				   
	case KI_VIDEO_CTRL:{
		
		CHECK_DEV;
		
		uint8_t video_ctrl;
		memcpy(&video_ctrl,data,1);
		ret=do_sth();
	}
	printf("done\n");
	break;
		
	case KI_SNAPSHOT:{
		
		time_t now;
		now = time((time_t*)NULL);
		struct tm *l_time;
		l_time = localtime(&now);
		char pic_name[127];
		bzero(pic_name,127);
		strftime(pic_name,sizeof pic_name,"%g_%m_%d_%H_%M_%S",l_time);
		strcat(pic_name,".jpg");
		
		msgp.nType = GET_PIC;
		sprintf(msgp.nContent,"%s",pic_name);
		
		if (msgsnd(msqid,&msgp,ARGS_MSG_SIZE,IPC_NOWAIT)!=0) {
			ret = RPL_UNKOWN_ERR;
		}
		else
			ret=RPL_OK;
	}
	printf("\n");
	break;


	case KI_QUIT:{
		if (*is_me==1&&g_is_dev_busy==1) {
			g_is_dev_busy=0;
			is_me=0;
		}
		ret =KI_QUIT;
	}
	printf("\n");
	break;
		
	default:
		ret = RPL_SYNTAX_ERR;
		printf("\n");
		break;
	}//end switch
	return ret;
}


