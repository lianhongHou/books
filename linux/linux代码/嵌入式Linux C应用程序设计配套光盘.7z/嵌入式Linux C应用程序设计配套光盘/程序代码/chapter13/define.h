#ifndef BLX_DEFINE_H
#define	BLX_DEFINE_H

#include "types.h"
struct _control_data_header {
	uint16_t	len;	
	unsigned int	type:4;	
	unsigned int	mo:4;	
	uint8_t	ttl;					
	uint8_t	ki;	
};

typedef struct _control_data_header ctl_hdr;

//type
#define TYPE_SET	1
#define TYPE_QUERY	2
#define TYPE_REPLY	4

//user state option 4 bits
#define MO_SERVER		0
#define MO_CLIENT		1
#define MO_BROADCAST	2
#define MO_CTRL_SET		3
#define MO_CTRL_GET		4
#define MO_CTRL_REPLAY	5

//type option							data format
#define KI_ACCESS_MOD	   100				//1
#define KI_IP_SET		   101						//IP����
#define KI_RATE_SET		   102				//4
#define KI_FRAME_SET	   103				//1byte
#define KI_RESOLUTION_SET	104			//4byte,2byte:horizontal;2byte vertical
#define KI_CAPTION_SET	   105				//
#define KI_BCSH_SET		   106			//5bytes ,bright,contrast,saturation,sharp,hue
#define KI_YUNTAI		   107				//2 bytes
#define KI_SAVE_POLICY_SET	  108			//
#define KI_SYSLOG		     	  109
#define KI_FILE_SEARCH        	  110
#define KI_FILE_DOWNLOAD   	  111
#define KI_CONFIG_RESET		  112			// no data 
#define KI_SPEAK_CTRL	         113				//1byte
#define KI_HISTORYVIDEO_CTRL 114			//
#define KI_HEARTBEAT	115				//
#define KI_REGISTER		116
#define KI_ALERT			117				//1byte,server to client
#define KI_REPLY			118				// 1byte server to client
#define KI_GET_FILELIST 119				//1bite ,file type
#define KI_GET_FILE		120				//1byte,file type and a string ,file name
#define KI_DEL_FILE		121				//
#define KI_VIDEO_CTRL	122				//1 byte
#define KI_MOTION_DETECTOR_SET	124		//24bytes,region,left,right,top,bottom,thresh
#define KI_MOTION_DETECTOR_STOP	125		//4byte region
#define KI_GOP_STRUCTURE_SET		126		//8byte N,M
#define KI_SNAPSHOT		127
#define KI_START			128
#define KI_STOP			129
#define KI_SETTING_END	130
#define KI_QUIT			'Q'


//the definition of the YUNTAI
#define YT_STOP		0
#define YT_UP		1
#define YT_DOWN		2
#define YT_LEFT		3
#define YT_RIGHT	4
#define YT_IRIS_P	5		//iris +		
#define YT_IRIS_M	6		//iris -
#define YT_ZOOM_P	7		//zoom +
#define YT_ZOOM_M	8		//zoom -
#define YT_FOCUS_P	9		//focus +
#define YT_FOCUS_M	10		//focus -
#define YT_AUTOSCAN_P	11  //autoscan +
#define YT_AUTOSCAN_M	12	//autoscan -


//replay message
#define RPL_OK			0
#define RPL_SYS_ERR		1
#define RPL_NOSIGNAL	2
#define RPL_NOSPACE		3
#define RPL_SYNTAX_ERR	4
#define RPL_ARG_ERR		5
#define RPL_QUERY_ERR	6
#define RPL_READ_ERR	7
#define RPL_WRITE_ERR	8
#define RPL_DEV_NOMOV	9 //device cannot move
#define RPL_NOFILE		10

#define RPL_AUTH_PASSED 11
#define RPL_AUTH_FAILED 12
//... other error
#define RPL_NOT_IMPLEMENT 254
#define RPL_UNKOWN_ERR	255

#define RPL_RUNNING		253
#define RPL_DEV_BUSY	'B' 


#define SPEAK_START		'1'
#define SPEAK_STOP		'2'

#endif
