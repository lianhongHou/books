/*hello.h*/
#ifndef _HELLO_H_
#define _HELLO_H_

typedef unsigned long val32_t;

#endif
