/*hello.c*/
#include <stdio.h>
#include <stdlib.h>
#include "hello.h"

int main()
{
        val32_t i = 5;
        printf("hello, embedded world %d\n",i);
}
