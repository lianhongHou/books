#ifndef __S3C2410FB_H
#define __S3C2410FB_Hstruct s3c2410fb_info {	struct fb_info		fb;	struct device		*dev;
	/* raw memory addresses */	dma_addr_t		map_dma;	/* physical */	u_char *		map_cpu;	/* virtual */	u_int			map_size;
	/* addresses of pieces placed in raw buffer */	u_char *		screen_cpu;	/* virtual address of frame buffer */	dma_addr_t		screen_dma;	/* physical address of frame buffer */	u32 pseudo_pal[16];};

int s3c2410fb_init(void);#endif

