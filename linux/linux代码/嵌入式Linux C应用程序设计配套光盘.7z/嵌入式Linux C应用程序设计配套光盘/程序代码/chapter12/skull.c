#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/kernel.h>
#include <linux/malloc.h>
#include <asm/segment.h>
#include <asm/uaccess.h>
#include <linux/errno.h>
unsigned int xsbase_major =0;
static char *data;
static ssize_t test_read(struct file *file, char *buf, size_t count, loff_t *f_pos);
static ssize_t test_write(struct file *file,const char *buffer, size_t count,loff_t *f_pos);
static int test_open(struct inode *inode, struct file *file);
static int test_release(struct inode *inode,struct file *file);
int init_module(void);
void cleanup_module(void);
static struct file_operations chr_fops={
	NULL,
	read:	test_read,
	write:	test_write,
	NULL,
	NULL,
	NULL,
	NULL,
	open:	test_open,
	release:	test_release,
	NULL,
};
static ssize_t test_read(struct file *file, char *buf, size_t count, loff_t *f_pos)
{
	int len;
	if(count<0)
		return -EINVAL;
	len = strlen(data);
	if(len < count)
		count = len;
	copy_to_user(buf,data,count+1);
	return count;
}
static ssize_t test_write(struct file *file,const char *buffer, size_t count,loff_t *f_pos)
{
	if(count < 0)
		return -EINVAL;
	kfree(data);
	data = (char *)kmalloc(sizeof(char)*(count+1),GFP_KERNEL);
	if(!data)
		return -ENOMEM;
	copy_from_user(data,buffer,count+1);
	return count;
}
static int test_open(struct inode *inode, struct file *file)
{
	MOD_INC_USE_COUNT;
	printk("This is open\n");
	return 0;
}
static int test_release(struct inode *inode,struct file *file)
{
	MOD_DEC_USE_COUNT;
	printk("this is released\n");
	return 0;
}
int init_module(void)
{
	int res;
	res=register_chrdev(0,"xsbase",&chr_fops);
	if(res<0)
	{
		printk("can't get major name!\n");
		return res;
	}
	if(xsbase_major == 0)
		xsbase_major = res;
	return 0;
}
void cleanup_module(void) {unregister_chrdev(xsbase_major,"xsbase");}
