#include <unistd.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void lock_set(int fd,int type);
int lock_reg(int fd, int cmd, int type, off_t offset, int whence, off_t len)��

int main(int argc, char *argv[])
{
	int fd,nwrite,nread,len, c;
	char reply;
	char buff[100];
	char buf_r[100];
	/*���ļ�*/
	fd=open("hello",O_RDWR | O_CREAT, 0666);
	if(fd < 0){
                perror("open");
                exit(1);
        }
	/*ʹ��getopt������ȡ�ͻ���ѡ��*/
	while ((c = getopt(argc, argv, "w:r")) != -1)
	switch(c)
	{
		/*����д����*/
		case 'w':
			strcpy(buff, optarg);
			lock_set(fd, F_WRLCK);
			len = sizeof(buff);
        		if((nwrite=write(fd,buff,len))>0){
                		printf("write success\n");
			}
			while(1)
			{
				printf("want to unlock?(Y/N)\n");
				scanf("%c",&reply);
				/*���ļ�����*/
				if((reply == 'Y') || (reply == 'y'))
				{
					lock_set(fd, F_UNLCK);
					break;
				}
				else
				{
					sleep(2);
					continue;
				}
			}
			break;
		/*�����ȡ��*/
		case 'r':
			lock_set(fd, F_RDLCK);
        		lseek(fd,0,SEEK_SET);
        		if((nread=read(fd,buf_r,100)) > 0){
                		printf("read:%s\n",buf_r);
        		}
			while(1)
			{
				printf("want to unlock?(Y/N)\n");
				scanf("%c",&reply);
				/*���ļ�����*/
				if((reply == 'Y') || (reply == 'y'))
				{
					lock_set(fd, F_UNLCK);
					break;
				}
 				else
				{
					sleep(2);
					continue;
				}
			}
			break;
		default:
			printf("prog [-w+content] [-r]\n");
			break;
	}
	close(fd);
	exit(0);
}

/*����������*/
lock_test(int fd, int type, off_t offset, int whence, off_t len)
{
	struct flock lock;
	lock.l_type = type; /*����ΪF_RDLCK����F_WRLCK*/
	lock.l_start = offset;
	lock.l_whence = whence;
	lock.l_len = len;
	if(fcntl(fd, F_GETLK, &lock) < 0)
		perror("fcntl");
	if(lock.l_type == F_UNLCK)
		return(0);
	return(lock.l_pid);
}
/*���ļ�������������*/
int lock_reg(int fd, int cmd, int type, off_t offset, int whence, off_t len)
{
	struct flock lock;
	lock.l_type = type; /*F_RDLCK, F_WRICK, F_UNLCK*/
	lock.l_start = offset;
	lock.l_whence = whence;
	lock.l_len = len;
	return(fcntl(fd, cmd, &lock))
}

