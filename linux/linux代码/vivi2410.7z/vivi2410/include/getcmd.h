#ifndef _VIVI_GETCMD_H_
#define _VIVI_GETCMD_H_


/* API */
void vivi_shell(void);

#endif /* _VIVI_GETCMD_H */
