/*
 * xmodem.h
 *
 */

/* returns the number of bytes transferred */
__u32 xmodem_receive(char *dest, size_t len);
