#define VIVI_RELEASE "0.1.4"
#define VIVI_VERSION_CODE 260
#define VIVI_VERSION(a,b,c) (((a) << 16) + ((b) << 8) + (c))
