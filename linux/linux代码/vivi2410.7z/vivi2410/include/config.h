/* rough config.h */

/*
 * History
 *
 * 2002-01-16: Nandy Lyu <nandy@mizi.com>
 *    - Initial code
 *
 */

#ifndef _CONFIG_H_
#define _CONFIG_H_

#include "autoconf.h"

#define CONFIG_COMMANDS 1
#define CONFIG_CMD_NET 1
#define CFG_CMD_NET 1
#define CFG_CMD_RARP 1
#define CFG_CMD_TFTP 1
//#define CFG_CMD_DHCP 1
//#define CFG_CMD_BOOTP 1
#define CFG_CMD_PING 1

#ifdef CONFIG_DRIVER_CS8900
#define CS8900_BASE 0x19000300
#define CS8900_BUS16 1
#else
#define CONFIG_DRIVER_DM9000	1	/* we have a CS8900 on-board */
#define DM9000_BASE		0x19000300
#endif

#define CONFIG_ETHADDR		08:01:3e:26:0a:5b 
#define CONFIG_NET_IP		"192.168.0.11"
#define CONFIG_NET_MASK		"255.255.255.0"
#define CONFIG_NET_GATEWAY	"192.168.0.10"
#define CONFIG_NET_SERVERIP	"192.168.0.10"
/*
#define CONFIG_ETHADDR		08:00:3e:26:0a:5b 
#define CONFIG_NETMASK          255.255.255.0
#define CONFIG_IPADDR		192.168.0.11
#define CONFIG_SERVERIP		192.168.0.10
*/



#endif /* _CONFIG_H_ */
