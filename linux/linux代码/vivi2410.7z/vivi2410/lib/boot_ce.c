/*
 * vivi/lib/boot-kernel.c: copy the kernel image to ram, then execute it 
 *
 *
 */

#include "config.h"
#include "machine.h"
#include "boot_kernel.h"
#include "priv_data.h"
#include "command.h"
#include "vivi_string.h"
#include "printk.h"
#include "mmu.h"
#include <types.h>
#include <setup.h>
#include <string.h>

#define CE_OFFSET	0x200000

#ifdef CONFIG_S3C2410_NAND_BOOT
extern int nand_read_ll(unsigned char*, unsigned long, int);
#endif
/*
 * dst: destination address
 * src: source
 * size: size to copy
 * mt: type of storage device
 */
static inline int copy_ce_img(ulong dst, const char *src, size_t size, int mt)
{
	int ret = 0;
	switch (mt) {
		case MT_RAM:	/* �̹� ���� �����Ƿ� ������ �ʿ� ���� */
			/* noting to do */
			break;
		case MT_SMC_S3C2410: 
			ret = nand_read_ll((unsigned char *)dst, 
					   (unsigned long)src, (int)size);
			break;
		default:
			printk("Undefined media type.\n");
			return -1;
	}
	return ret;
}

static inline int media_type_is(const char *mt)
{
	if (strncmp("ram", mt, 3) == 0) {
		return MT_RAM;
	} else if (strncmp("nor", mt, 3) == 0) {
		return MT_NOR_FLASH;
	} else if (strncmp("smc", mt, 3) == 0) {
		return MT_SMC_S3C2410;
	} else {
		return MT_UNKNOWN;
	}
}

int boot_ce(ulong from, size_t size, int media_type)
{
	int ret;
	ulong boot_mem_base;	/* base address of bootable memory �³�? */
	ulong to;
	ulong mach_type;
	void (*F)(void);

	boot_mem_base = get_param_value("boot_mem_base", &ret);
	if (ret) {
		printk("Can't get base address of bootable memory\n");
		printk("Get default DRAM address. (0x%08lx\n", DRAM_BASE);
		boot_mem_base = DRAM_BASE;
	}

	/* copy kerne image */
	//to = boot_mem_base + CE_OFFSET;
	to=0x30200000;
	printk("Copy linux ce from 0x%08lx to 0x%08lx, size = 0x%08lx ... ",
		from, to, size);
	ret = copy_ce_img(to, (char *)from, size, media_type);
	if (ret) {
		printk("failed\n");
		return -1;
	} else {
		printk("done\n");
	}

		/* Get machine type */
	mach_type = get_param_value("mach_type", &ret);
	printk("MACH_TYPE = %d\n", mach_type);

	/* Go Go Go */
	/* ������� ���� �̻�����??? */
	exec_string("go 0x30200000");
		
        return 0;
}
	

/*
 * User Commands
 */

static inline void display_help(void)
{
	printk("this command is boot wince\n");
}


void command_boot_ce(int argc, const char **argv)
{
	int media_type = 0;
	ulong from = 0;
	size_t size = 0;
	mtd_partition_t *kernel_part;
	int ret;
	

	switch (argc) {
		case 1:
			media_type = get_param_value("media_type", &ret);
			if (ret) {
				printk("Can't get default 'media_type'\n");
				return;
			}
			kernel_part = get_mtd_partition("ce");
			if (kernel_part == NULL) {
				printk("Can't find default 'ce' partition\n");
				return;
			}
			from = kernel_part->offset;
			size = 0x2000000;
			break;
		case 2:
		default:
			display_help();
			break;
	}

	boot_ce(from, size, media_type);
	
	
}

user_command_t boot_ce_cmd = {
	"bootce",
	command_boot_ce,
	NULL,
	"bootce"
};
