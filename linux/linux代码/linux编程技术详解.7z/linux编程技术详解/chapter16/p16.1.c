#include <gtk/gtk.h>

int main(int argc,char* argv[])
{
	GtkWidget *wnd;
	gtk_init(&argc,&argv);
	
	wnd=gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_widget_show(wnd);

	gtk_main();
	return 0;
}
