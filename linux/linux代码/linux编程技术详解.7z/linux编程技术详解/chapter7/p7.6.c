#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main(void){
	fork();
	printf("Will be executed twice\n");
	return 0;
}

