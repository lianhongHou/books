class Matrix2D
{
  private int[][] matrix;

  public Matrix2D(int sizex, int sizey)
  {
    matrix = new int[sizex][sizey];
  }
  public void addMatrix(Matrix2D other)
  {
    //add other to this.
  }
  public void multiplyMatrix(Matrix2D other)
  {
    //multiply other by this.
  }
  public int elementAt(int row, int col)
  {
    //return element at row/col
    return 1;
  }
  //...
}
