class Test
{
  private int[] ia1;
  private int[] ia2;
  private double[] da1;
  private double[] da2;


  public synchronized void method1()
  {
    //Access ia1 and ia2
  }
  public synchronized void method2()
  {
    //Access ia1 and ia2
  }
  public synchronized void method3()
  {
    //Access da1 and da2
  }
  public synchronized void method4()
  {
    //Access da1 and da2
  }
  //...
}