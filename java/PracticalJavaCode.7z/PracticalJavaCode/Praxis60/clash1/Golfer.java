interface Golfer
{
  public static final int HighScore = 90;
  public static final int LowScore = 72;
  public int computeScore();
}