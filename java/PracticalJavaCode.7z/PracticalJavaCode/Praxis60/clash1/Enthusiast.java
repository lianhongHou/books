class Enthusiast implements Golfer, Bowler
{
  public void computeScore()
  {
    //...
  }
}