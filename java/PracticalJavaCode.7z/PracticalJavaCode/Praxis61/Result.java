class Result extends TeamScores
{
  public int player1Score(int holeNum, Team team)
  {
    int score;
    //score = lookup holeNum score for player1 on given team
    return score;
  }

  public int player2Score(int holeNum, Team team)
  {
    int score;
    //score = lookup holeNum score for player2 on given team
    return score;
  }

  public void storeTeamScore(int score, Team team)
  {
    //Store score for team...
  }
}