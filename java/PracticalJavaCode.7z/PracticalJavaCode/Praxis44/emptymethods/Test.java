//Empty methods
class Test
{
  static void foo()
  {}
  final public void bar()
  {}
  public static void main(String args[])
  {
    Test t = new Test();
    t.foo();
    t.bar();
  }
}