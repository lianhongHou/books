class Test
{
  public static void main(String args[])
  {
    int a = 10;
    int b = 10;
    System.out.println("a==b is " + (a==b));

    Integer ia = new Integer(10);
    Integer ib = new Integer(10);
    System.out.println("ia==ib is " + (ia==ib));
  }
}