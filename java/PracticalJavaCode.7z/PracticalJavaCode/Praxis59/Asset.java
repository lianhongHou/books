interface Asset
{
  public int initialCost();
  public int currentValue();
  public double rateOfGrowth();
}
