class Circle
{
  private double radius;

  public Circle(double r)
  {
    radius = r;
  }

  public void setRadius(double r)
  {
    radius = r;
  }

  public double radius()
  {
    return radius;
  }
}